#!/bin/bash

g++ -std=c++11 lineups.cpp -o lineups
./full_gen.sh 20191030_TEN_DKSalaries.csv tennis
