#!/bin/bash
./lineups 2 draftkings tennis $1 > ./20191030_tennis_lineups_2.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Bautista-Agut" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Dimitrov" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Tsonga" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Cilic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Edmund" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep "Pliskova" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Dimitrov" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Tsonga" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Cilic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Edmund" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Bautista-Agut" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Tsonga" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Cilic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Edmund" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Dimitrov" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Cilic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Edmund" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Tsonga" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Edmund" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Cilic" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Raonic" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Edmund" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Fognini" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Raonic" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fognini" ./20191030_tennis_lineups_2.csv | grep " Paire" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fognini" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fognini" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fognini" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fognini" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Paire" ./20191030_tennis_lineups_2.csv | grep " Garin" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Paire" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Paire" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Paire" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Garin" ./20191030_tennis_lineups_2.csv | grep " Fritz" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Garin" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Garin" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fritz" ./20191030_tennis_lineups_2.csv | grep " Mannarino" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Fritz" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
grep " Mannarino" ./20191030_tennis_lineups_2.csv | grep " Moutet" >> ./20191030_tennis_lineups.csv
echo >> ./20191030_tennis_lineups.csv
